
<!-- Menu lateral-->
	<div class="sideleft">
		<div class="nav-login">
			<ul>
				<?php
						if(empty($_SESSION['usuario'])){
							echo "<li><a href='login.php'> Login </a></li>
								  <li><a href='cadastro.php'> Cadastro </a></li>";
						}else{
							echo "<li><a href='sair.php'>Sair</a></li>";
						}

				?>
				
			</ul>
		</div>

		
		<nav class="">
			<ul class="nav flex-column">
		  		<li class="nav-item" >
		   	 		<a class="nav-link active dropdown-toggle title-nav" href="#">Doenças/Tratamentos</a>
		   	 		<div class="menu-escondido">
		   	 			<ul>
		   	 				<li><a href=""> teste</a></li>
		   	 				<li><a href="">	teste</a></li>
		   	 				<li><a href="">	teste</a></li>
		   	 			</ul>
		   	 		</div>		
		  		</li>

		  		<li class="nav-item">
		    		<a class="nav-link dropdown-toggle title-nav" href="#">Especialistas</a>
		    		<div class="menu-escondido">
		   	 			<ul>
		   	 				<li><a href=""> teste</a></li>
		   	 				<li><a href="">	teste</a></li>
		   	 				<li><a href="">	teste</a></li>
		   	 			</ul>
		   	 		</div>	
		  		</li>
				<li class="nav-item">
				    <a class="nav-link  dropdown-toggle title-nav" href="#">Parcerias</a>
				    <div class="menu-escondido">
		   	 			<ul>
		   	 				<li><a href=""> teste</a></li>
		   	 				<li><a href="">	teste</a></li>
		   	 				<li><a href="">	teste</a></li>
		   	 			</ul>
		   	 		</div>	
				</li>
				<li class="nav-item">
				    <a class="nav-link title-nav" href="#">Ajuda</a>
				</li>
			</ul>	
		</nav>
	</div>
<!-- Menu lateral-->