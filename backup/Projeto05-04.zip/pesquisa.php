<?php 

include("conecta.php");

//Comando SQL para verificação no banco de dados
$consulta = mysqli_query($conexao, "SELECT * FROM usuario 
						WHERE email ='$email' and senha = '$senha' ");

$linha = mysqli_num_rows($consulta);

//cria um array com as informações
$dados_usuario = mysqli_fetch_assoc($consulta);

	if(isset($dados_usuario))
	 {
		$_SESSION['login'] = $login;

		$_SESSION['logado'] = 'true';
	 	$_SESSION['senha'] = $senha;
	 	$_SESSION['usuario'] = $dados_usuario['nome_completo'];
	 	header('location:index.php');
	}
	else{
	   	unset ($_SESSION['login']);
	  	unset ($_SESSION['senha']);
	  	header('location:login.php');
	}

?>
