<?php 

// session_start inicia a sessão
session_start();

$email = $_POST["email"];
$senha = $_POST["senha"];

//Conecção com o banco de dados
$host = "localhost";
$user = "root";
$senha_conexao = "";
$database = "db_clinica";

$conexao = mysqli_connect($host,$user,$senha_conexao,$database);
?>
