<?php 
include("conecta.php");

?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

	teste

</body>
</html>