<?php 

// session_start inicia a sessão
session_start();

$email = $_POST["email"];
$senha = $_POST["senha"];

//Conecção com o banco de dados
$host = "localhost";
$user = "root";
$senha_conexao = "";
$database = "db_clinica";

$conexao = mysqli_connect($host,$user,$senha_conexao,$database);

//Comando SQL para verificação no banco de dados
$consulta = mysqli_query($conexao, "SELECT * FROM usuario 
						WHERE email ='$email' and senha = '$senha' ");


$linha = mysqli_num_rows($consulta);

//cria um array com as informações
$dados_usuario = mysqli_fetch_assoc($consulta);

	if(isset($dados_usuario))
	 {
		$_SESSION['login'] = $login;

		$_SESSION['logado'] = 'true';
	 	$_SESSION['senha'] = $senha;
	 	$_SESSION['usuario'] = $dados_usuario['nome_completo'];
	 	header('location:index.php');
	}
	else{
	   	unset ($_SESSION['login']);
	  	unset ($_SESSION['senha']);
	  	header('location:login.php');
	}

?>
