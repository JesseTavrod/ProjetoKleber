
<?php include('header.php');?>
<div class="row">
	<div class="col-3 ">
		<?php
			include('includes/menu.php');
		?>
	</div>
	<div class="col-9">
		<div class="menu-topo"> 
			<h1>PsicoHelp</h1>
			<div class="btn-contato"><a href="contato.php">Entrar em contato</a></div>
		</div>
		<main>
				<?php 
				if(!empty($_SESSION['usuario'])){
					echo "<div class='text-danger float-right mr-3 mt-3'>".'Bem vindo !! '.$_SESSION['usuario']."</div>";
				}else{
					echo "";
				}
				?>
			</div>	
		</main>
	</div>
</div>


<section class="page">
	

</section>
<?php include('footer.php');?>