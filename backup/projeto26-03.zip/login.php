<?php 

	//verificação se a sessão ja está logada
	if (!empty($_SESSION['usuario'])) {
		header('location:index.php');
	} else{
		include('header.php');
?>		
<section class="login">
	<div class="row">
		<div class="col-sm-3">
			<div class="formulario-login">
				<form action="conecta.php" method="POST">
					<div class="titulo-form">Tela de login</div>
					<div class="form-group">
						<label>Email:</label><br>
						<input class="form-control" type="text" name="email" required>
					</div>
					<div class="form-group">
						<label>Senha:</label><br>
					    <input class="form-control" type="password" name="senha" required>  
					</div>
					<a href="#"><span>Esqueceu a senha?</span></a><br>
					<a href="cadastro.php"><span>Faça seu cadastro já!</span></a>
					<div class="btn-formulario">
						<button class="btn-login" type="submit">Logar</button>
					</div>
				</form>	
			</div>
		</div>
		
	</div>
	

	<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
 		<div class="modal-dialog modal-dialog-scrollable" role="document">
	    	<div class="modal-content">
	      		<div class="modal-header">
		        	<h5 class="modal-title" id="exampleModalScrollableTitle">Recuperação de senha.</h5>
		        	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          		<span aria-hidden="true">&times;</span>
		        	</button>
		      	</div>
		      	<div class="modal-body">
		        	<form >
		        		<div class="form-group mb-0">
		        			<label>Ensira seu Email:</label><br>
							<input class="form-control" type="email" name="txt_usuario" required>	
		        		</div>
						<div class="text-right">
							<button class="btn-recuperacao" type="submit">Recuperar</button>
						</div>
		        	</form>
		      	</div>
	    	</div>
  		</div>
	</div>
	
</section>

<?php 
	include('footer.php');
	}
	//fim da verificação
?>