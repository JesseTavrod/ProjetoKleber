<?php 
session_start();

if(isset($_SESSION['logado'] = 'true')){
	include('header.php');
	include('template/site.php');
	include('footer.php.php');
}else{
	header('location:login.php');}
?>



<?php
	
?>

<div>

	<h1>
		Bem Vindo
		<div class="text-danger">
			<?php echo $_SESSION['usuario'];?>	
		</div>
	</h1>

</div>
</body>
</html>